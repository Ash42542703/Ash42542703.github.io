
/**
 * Write a description of class BBUC here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;//importing the scanner
import java.util.Random;//importing the random generator
public class BBUC{//start of the class
 public static void main(String args[]){//start of the code
  Scanner scan = new Scanner(System.in);//giving the scanner a name
  Random rand = new Random();//giving the random generator a name
  BBUC b = new BBUC();//create a name for the class
  BBUCCard user1id = new BBUCCard();//calling the card information for user 1
  BBUCCard user2id = new BBUCCard();//calling the card information for user 2
  BBUCCard user3id = new BBUCCard();//calling the card information for user 3
  user1id.setName("Taylor");//setting the name for user 1
  user1id.setage(19);//setting the age for user 1
  user1id.setID(782395);//setting the id for user 1
  System.out.println("Hello User! Do you have an account with us?");//gretting the user and asking if they have an account
  String ans = scan.next();//saving that answer
  if(ans.equals("yes")){// if that answer is yes do this
   System.out.println("Perfect! Please input your ID number (if you forgot your id number enter -1)");//asking the user for their id and if they forgot it input -1
   int id = scan.nextInt();//saving their answer
   if(id == -1){//if the answer is -1 do this
    System.out.println("Please don't Panic unless your quirky like that");//joking with the user about them forgeting their id
    System.out.println("Enter your name, and we will see if we have you on record");//asking the user to input their name to see if it is presaved
    String name = scan.next();//saving their answer
    if(name.equals(user1id.getName()) || name.equals(user2id.getName()) || name.equals(user3id.getName())){//if the name they inout is equal to any of the names in any of the user names
     if(name.equals(user1id.getName())){//if the name is equal to user 1 name do this
      System.out.println("Hello, " +user1id.getName()+ " Welcome back, let's get started");//saying hi to the user and contining with the program
     }else if(name.equals(user2id.getName())){//if the name is equal to user 2 name do this
      System.out.println("Hello, " +user2id.getName()+ " Welcome back, let's get started");//saying hi to the user and continuing with the program
     }else{//if its neither of them then do this
      System.out.println("Hello, " +user3id.getName()+ " Welcome back, let's get started");//saying hi to the user and contining with the program
     }
    }
    while(id !=user1id.getID()|| id != user2id.getID() || id != user3id.getID()){//if the id is not equal to any of the presaved id's do this
     System.out.println("The id you are trying to input is incorrect, Please try again");//telling them that the id that they are inputting is wrong
     id = scan.nextInt();//letting them input the id again
    }
    }
   if(id == user1id.getID()|| id == user2id.getID() || id == user3id.getID()){//if the id equals any presaved id's do this
    if(id ==user1id.getID()){//if the id is equal to the user 1 id do this
     System.out.println("Hello, " +user1id.getName()+ " Welcome back, let's get started");//saying hi to the user and continuing with the program
    }else if(id == user2id.getID()){//if the id is equal to the user 2 id do this
     System.out.println("Hello, " +user2id.getName()+ " Welcome back, let's get started");//saying hi to the user and continuning with the program
    }else if(id == user3id.getID()){//if the id is equal to the user 3 is do this
     System.out.println("Hello, " +user3id.getName()+ " Welcome back, let's get started");//saying hi to the user and continuning with the program
    }
    }
   }else if(ans.equals("no")){//if the anwer is equal to no than do this
    System.out.println("Would you like to create an account?");//asking the user if they would like to create an account
    String account = scan.next();//saving their answer
    if(account.equals("yes")){//if their answer is equal to yes do this
     System.out.print("Enter your name");//asking the user to enter their name
     user2id.setName(scan.next());//takes the users name and saves it as user 2 name
     System.out.println("Hi! " +user2id.getName()+ " Please enter your age, so we can pick age appropriate selections for you");//asking the user to input their age
     user2id.setage(scan.nextInt());//saving their answer
     while (user2id.getage()<=13){//while their age is younger or is 13 do this
      System.out.println("Whoops, looks like you are too young to accsess this site, you need a parent to continue");//telling them that they are too young to continue to use the site
      break;//ending the code
     }
     System.out.println("Ok, " +user2id.getName()+ " Genterating your user id now (you may want to write it down for later or take a picture, I am a computer not a printer");//telling the user that the code is generating a random number which will be their id and telling them to save it for another time
     int idnum = rand.nextInt(999999);//generating a random number
     System.out.println("Your ID number is: "+idnum);//telling the user thier id number
    }else{//if they say no do this
     System.out.println("Have a Bustin Day! (Happy Scrolling)");//ending the code and telling them to have a good day, and joking with them and now they have to scroll tp find the movie/show they will watch
    }
   }
  int service = rand.nextInt(6);//creating a random number for the streaming services
  System.out.println("Generating the streaming service for you now...");//telling the user that generating one for them
  System.out.println(b.Service());//printing out the service
  System.out.println("Would you like to use this service?");//asking if they would like to use the service we have selected
  String choice = scan.next();//saving their answer
  while(choice.equals("no")){//if the answer is equal to no do this
   System.out.println(b.Service());//printing out a differnt service
   System.out.println("would you like to use this service?");//asking if they want to use that service
   choice = scan.next();//saving their answer
  }
  if(choice.equals("yes")){//if their is equal to yes then do this
   System.out.println("Perfect! Now select your genera");//now telling the user that they can select the genera they want to watch
  }
  System.out.println("1: Drama");//printing out drama as 1
  System.out.println("2: Comedy");//printing comedy as 2
  System.out.println("3: Sports");//printing Sports as 3
  System.out.println("4: Action/Adventure");// printing Action/Adventure as 4
  System.out.println("5: Kids/Family");//printing Kids/Family as 5
  System.out.println("6: Romance");//printing Romance as 6
  System.out.println("7: Horror");//printing Horror as 7
  System.out.println("8: Documentary");//printing Documentary as 8
  System.out.println("9: Sci-Fi");//printing Sci-Fi as 9
  System.out.println("😉🧚‍♀️");//it looks like just some fun emojis, but if you type 10 then it's a secret
  int genera = scan.nextInt();//saving their answer
  if(service == 1 && genera == 1){//if the service is equal to 1 and the genera is equal to 1 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
    String viewing = scan.next();//saving their answer
   if(viewing.equals("movie")){//if the answer is equal to movie do this
    if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("The Noel Diary");//print out this movie
      System.out.println("Tick, Tick...BOOM!");//print out this movie
      System.out.println("Hunt for the Wilder People");//print out this movie
    }else{//if the users age is bigger than 18 do this
     System.out.println("Don't Look Up");//print out this movie
     System.out.println("Marriage Story");//print out this movie
     System.out.println("Lou");//print out this movie
     }
    }else{//if the answer is not equal to movie do this
     if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){
      System.out.println("Never Have I Ever");//print out this show
      System.out.println("Anne with an 'E'");//print out this show
      System.out.println("Atypical"); //print out this show
    }else{
     System.out.println("Wednesday");//print out this show
     System.out.println("Alice in Borderland");//print out this show
     System.out.println("Bridgerton");//print out this show
   }
   }
   }
  if(service == 1 && genera == 2){//if service is equal to 1  genera is equal to 2 do this
    System.out.println("Would you like to watch a movie or a show");//asking if the user would like to watch a movie or a show
    String viewing= scan.next();//saving their answer
    if(viewing.equals("movie")){//if thier answer is equal to movie do this
     if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Wendell & Wild");//print out this movie
      System.out.println("The Box Trolls");//print out this movie
      System.out.println("Addams Family");//print out this movie
     }else{
     System.out.println("Kid Gorgeous");//print out this movie
     System.out.println("Murder mystery");//print out this movie
     System.out.println("Scooby-Doo (Live Action)");//print out this movie
     }
    }else{
    if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Total Drama Island");//print out this show
      System.out.println("Dead End: Paranormal Park");//print out this show
      System.out.println("Victorious");//print out this show
    }else{
     System.out.println("Tuca & Bertie");//print out this show
     System.out.println("The Good Place");//print out this show
     System.out.println("American Vandal");//print out this show
    }
   }
   }
   if(service == 1 && genera == 3){//if service is equal to 1  genera is equal to 3 do this
    System.out.println("Would you like to watch a movie or a show");//asking if they want to watch a show or a movie
     String viewing = scan.next();//saving their answer
    if(viewing.equals("movie")){//if their answer is equal to movie do this
     if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Moneybal");//print out this movie
      System.out.println("Home Team");//print out this movie
      System.out.println("The Swimmers");//print out this movie
     }else{
     System.out.println("The Swimmers");//print out this movie
     System.out.println("Bruised");//print out this movie
     System.out.println("Little miss Sumo");//print out this movie
     }
    }else{
     if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("All American");//print out this movie
      System.out.println("Titletown High");//print out this movie
      System.out.println("Basketball or Nothing");//print out this movie
    }else{
     System.out.println("Cheer");//print out this show 
     System.out.println("Formula 1: Drive to survive");//print out this show
     System.out.println("All American");//print out this show
    }
   }
  }
  if(service == 1 && genera == 4){//if service is equal to 1  genera is equal to 4 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
    String viewing = scan.next();//saving their answer
   if(viewing.equals("movie")){//if their answer is equal to movie do this
    if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Scooby-Doo (Live Action)");//print out this movie
      System.out.println("Enola Holmes");//print out this movie
      System.out.println("Vampire Academy");//print out this movie
    }else{//if the users age is over 18 do this
     System.out.println("What Happened to Monday");//print out this movie
     System.out.println("Labryinth");//print out this movie 
     System.out.println("Animal World");//print out this movie
    }
    }else{//if their answer is not equal to movie do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("The Dragon Prince: Mystery of Avravos");//print out this show
      System.out.println("Jim Henson's The Dark Crystal: Age of Resistance");//print out this show
      System.out.println("The Flash");//print out this show
    }else{//if the users age is over 18 than do this 
     System.out.println("Arcane");//print out this show
     System.out.println("Lock & Key");//print out this show
     System.out.println("The Umbrella Academy");//print out this show
    }
    }
  }
  if(service == 1 && genera == 5){//if service to service is equal to 1  genera is equal to 5 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
    String viewing = scan.next();//saving that answer 
   if(viewing.equals("movie")){//if their anser is equal to movie do this
    if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("The Michell's Vs the Machienes");//print out this movie
      System.out.println("The Sea Beast");//print out this movie
      System.out.println("Over the Moon");//print out this movie
    }else{//if the users age is bigger than 18 do this
     System.out.println("The Michells vs the Machines");//print out this movie
     System.out.println("The Sea Beast");//print out this movie
     System.out.println("Over The Moon");//print out this movie
    }
    }else{//if the users answer does not equal movie
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Project MC^2");//print out this show
      System.out.println("Carmon Sandiego");//print out this show
      System.out.println("Hilda");//print out this show
    }else{//if the users age is bigger than 18 do this
     System.out.println("Project MC^2");//print out this show 
     System.out.println("Carmen Santigeo");//print out this show
     System.out.println("Hilda");//print out this show
    }
    }
  }
  if(service == 1 && genera == 6){//if service is equals 1  genera is equal to 6
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
    String viewing = scan.next();//saving that answer
   if(viewing.equals("movie")){//if their answer is equal to movie do this
       if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("The Half of It");//print out this movie
      System.out.println("The princess Switch");//print out this movie
      System.out.println("Always Be My Maybe");//print out this movie
    }else{//if the users age is bigger than 18 do this
     System.out.println("The Half of It");//print out this movie
     System.out.println("20th Century Girl");//print out this movie
     System.out.println("How to Lose a Guy in 10 Days");//print out this movie
    }
    }else{//if the users answer is not equal to movie do this
     if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Love Between a Fairy and Devil");//print out this show
      System.out.println("Zac & Mia");//print out this show
      System.out.println("Dash & Lily");//print out this show
    }else{//if the users age is bigger than 18 do this
     System.out.println("Alchemy of Souls");//print out this show
     System.out.println("From Sratch");//print out this show
     System.out.println("The Big Day");//print out this show
    }
    }
  }
  if(service == 1 && genera == 7){//if service is equal to 1  genera is equal to 7 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
   String viewing = scan.next();//saving their answer
   if(viewing.equals("movie")){//if the users anser is equal to movie do this
       if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("You are too young to watch horror, we recomend Scooby-Doo");//print out this movie
    }else{//if the users age is bigger than 18 then do this
     System.out.println("The Mist");//print out this movie
     System.out.println("Cadaver");//print out this moive
     System.out.println("In the Tall Grass");//print out this movie
    }
    }else{//if the users answer does not equal movie do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("You are too young to watch horror, we recommend Scooby-Doo");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("Midnight Mass");//print out this show
     System.out.println("Archive 81");//print out this show
     System.out.println("Hellbound");//print out this show
    }
    }
  }
  if(service == 1 && genera == 8){//if service equals 1  genera equals 8 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
    String viewing = scan.next();//saving their answer
   if(viewing.equals("movie")){//if thier answer is equal to movie do this
       if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Inside the mind of a Cat");//print out this movie
      System.out.println("The Social Dilemma");//print out this movie
      System.out.println("Headspace: Unwind Your Mind");//print out this movie
    }else{//if the users age is over 18 do this
     System.out.println("Pray Away");//print out this movie
     System.out.println("Seaspiracy");//print out this movie
     System.out.println("Icarus");//print out this movie
    }
    }else{//if the users answer does not equal movie do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Our Planet");//print out this show
      System.out.println("Hight on Earth");//print out this show
      System.out.println("Myths & Monsters");//print out this show
    }else{//if the users age is over 18 then do this
     System.out.println("Explained");//print out this show
     System.out.println("Afflicted");//print out this show
     System.out.println("How to Change Your Mind");//print out this show
    }
    } 
  }
  if(service == 1 && genera == 9){//if service is equal to 1  genera is equal to 9 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
    String viewing = scan.next();//saving thier answer
   if(viewing.equals("movie")){//if their answer equals movie do this
       if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("The Adam Project");//print out this movie
      System.out.println("The Midnight Sky");//print out this movie
      System.out.println("The Space Between Us");//print out this movie
    }else{//if the user is over the age of 18 do this
     System.out.println("Spiderhead");//print out this movie
     System.out.println("The Cloverfield Paradox");//print out this movie
     System.out.println("Psychokinesis");//print out this movie
    }
    }else{//if the users answer does not equal movie then do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Lost in Space");//print out this show
      System.out.println("She-Ra");//print out this show
      System.out.println("Mystery Science Theater 3000: The Gauntlet");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("Altered Carbon");//print out this show
     System.out.println("Nightflyers");//print out this show
     System.out.println("Lost in Space");//print out this show
    }
    }
  }
  if(service == 2 && genera == 1){//if service is equal to 2  genera is equal to 1 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
    String viewing = scan.next();//saving thier answer
   if(viewing.equals("movie")){//if their answer is equal to movie do this
     if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("The Perks of Being a Wallflower");//print out this movie
      System.out.println("Mamma Mia!");//print out this movie
      System.out.println("How I live Now");//print out this movie
    }else{//if the user is over 18 then do this
     System.out.println("The Perks of Being a Wallflower");//print out this movie
     System.out.println("Mamma Mia!");//print out this movie
     System.out.println("How I live Now");//print out this movie
    }
    }else{//if the users answer is not equal to movie do this
      if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Buffy the Vampire Slayer");//print out this show
      System.out.println("Freaks  geaks");//print out this show
      System.out.println("The Librarians");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("The Dropout");//print out this show
     System.out.println("The Great");//print out this show
     System.out.println("Queen Sugar");//print out this show
    }
    }
  }
  if(service == 2 && genera == 2){//if service is equal to 2  genera is equal to 2 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
    String viewing = scan.next();//saving their answer
   if(viewing.equals("movie")){//if their answer equals movie do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("The Hundred-Foot Journey");//print out this movie
      System.out.println("Aquamarine");//print out this movie
      System.out.println("The Bob's Burgers Movie");//print out this movie
    }else{//if the user is over 18 do this
     System.out.println("Vacation Friends");//print out this movie
     System.out.println("Palm Springs");//print out this movie
     System.out.println("The Hundred-Foot Journey");//print out this movie
    }
    }else{//if the users answer does not equal movie do this
     if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Malcolm in the Middle");//print out this show
      System.out.println("The Amazing world of Gumball");//print out this show
      System.out.println("Abbott Elementary");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("Only Murders in the Building");//print out this show
     System.out.println("What we do in the Shadows");//print out this show
     System.out.println("Reservation Dogs");//print out this show
    }
    }
  }
  if(service == 2 && genera == 3){//if service equals 2  genera equals 3 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
    String viewing = scan.next();//saving their answer
   if(viewing.equals("movie")){//if their answer equals movie do this
      if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Born to Play");//print out this movie
      System.out.println("Stomp The Yard: Homecoming");//print out this movie
      System.out.println("Ford V Ferrari");//print out this movie
    }else{//if the user is over 18 do this
     System.out.println("The Radio");//print out this movie
     System.out.println("Hardball");//print out this movie
     System.out.println("I, Tonya");//print out this movie
    }
    }else{//if the users answer does not equal movie then do this
    if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Basketball and Other Things");//print out this show
      System.out.println("Behind the Mask");//print out this show
      System.out.println("The Game");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("Pitch");//print out this show
     System.out.println("The Leauge");//print out this show
     System.out.println("Brockmire");//print out this show
    }
    }
  }
  if(service == 2 && genera == 4){//if service is equal to 2  genera is equal to 4 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they would like to watch a movie or a show
    String viewing = scan.next();//saving their answer
   if(viewing.equals("movie")){//if their answer is equal to movie do this
       if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Bridge to Terbithia");//print out this movie
      System.out.println("Narnia: The Lion, The Witch, and the Wardrobe");//print out this movie
      System.out.println("Adventures in Babysitting");//print out this movie
    }else{//if the user is over 18 do this
     System.out.println("The Princess");//print out this movie
     System.out.println("The Ledge");//print out this movie
     System.out.println("The Perfect Storm");//print out this movie
    }
    }else{//if the users answer does not equal movie do this
     if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("The Owl House");//print out this show
      System.out.println("Wolverine and the X-Men");//print out this show
      System.out.println("Zorro");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("Over The Garden Wall");//print out this show
     System.out.println("The Librarians");//print out this show
     System.out.println("Firefly");//print out this show
    }
    }
  }
  if(service == 2 && genera == 5){//if service is equal to 2  genera is equal to 5 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
    String viewing = scan.next();//saving thier answer
   if(viewing.equals("movie")){//if their answer is equal to movie do this
       if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("The book of Life");//print out this movie
      System.out.println("Brother Bear");//print out this movie
      System.out.println("A Goofy Movie");//print out this movie
    }else{//if the user is over 18 do this
     System.out.println("A Cat in Paris");//print out this movie
     System.out.println("The Croods: A New Age");//print out this movie
     System.out.println("Diary Of A Wimpy Kid");//print out this movie
    }
    }else{//if the users answer does not equal movie do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Elena of Avalor");//print out this show
      System.out.println("Fishhooks");//print out this show
      System.out.println("Amphibia");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("Adventure Time");//printout this show
     System.out.println("Gravity Falls");//print out this show
     System.out.println("The Hardy Boys");//print out this show
    }
   }
  }
  if(service == 2 && genera == 6){//if service is equal to 2  genera is equal to 6 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
    String viewing = scan.next();//saving their answer 
   if(viewing.equals("movie")){//if thier answer equals movie do this
       if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("10 Things I Hate Aboout You");//print out this movie
      System.out.println("West Side Story");//print out this movie
      System.out.println("The Princess Bride");//print out this movie
    }else{//if the user is over 18 do this
     System.out.println("Tell it to the Bees");//print out this movie
     System.out.println("The Hating game");//print out this movie
     System.out.println("The Right One");//print out this movie
    }
    }else{//if the users answer does not equal movie do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("High School Musical the Musical the Series");//print out this show
      System.out.println("Disney's Fairy tale wedding");//print out this show
      System.out.println("Violetta");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("This is Us");//print out this show
     System.out.println("Four Weddings and A Funeral");//print out this show
     System.out.println("Love Island");//print out this show
    }
    }
  }
  if(service == 2 && genera == 7){//if service equals 2  genera equals 7 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
    String viewing = scan.next();//saving thier answer
   if(viewing.equals("movie")){
       if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("You are too young to watch a horror movie, we recommend Scooby-Doo (Live Action)");//print out this movie
    }else{//if the user is over 18 do this
     System.out.println("Parasite");//print out this movie
     System.out.println("47 Meters Down");//print out this movie
     System.out.println("Lantern's Lane");//print out this movie
    }
    }else{//if the users answer does not equal movie then do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("You are too young to watch a horror show, we recommend Scooby-Doo (Any form of Scooby-Doo show)");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("Castle Rock");//print out this show
     System.out.println("The Strain");//print out this show
     System.out.println("Freakish");//print out this show
    }
    }
  }
  if(service == 2 && genera == 8){//if service is equal to 2  genera is equal to 8 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user is they want to watch a movie or a show
    String viewing = scan.next();//saving the users answer
   if(viewing.equals("movie")){//if the users answer equals move do this
     if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Akashinga: The Brave Ones");//print out this movie
      System.out.println("Apollo: Missions to the Moon");//print out this movie
      System.out.println("Elephant");//print out this movie
    }else{//if the user is over 18 do this
     System.out.println("The Orange Years: The Nickelodeon Story");//print out this movie
     System.out.println("Untouchable");//print out this movie
     System.out.println("H. H. Holmes: Original Evil");//print out this movie
    }
    }else{//if the users answer does not equal movie then do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Cosmos: Possible Worlds");//print out this show
      System.out.println("Growing up Animal");//print out this show
      System.out.println("Growing Up");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("Victoria's Secret: Angels and Demons");//print out this show
     System.out.println("The Unexplained");//print out this show
     System.out.println("Ancient Top 10");//print out this show
    }
    }
  }
  if(service == 2 && genera == 9){//if service equals 2  genera equals 9 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they would like to watch a movie or a show
    String viewing = scan.next();//saving thier answer
   if(viewing.equals("movie")){//if their answer equals movie do this
       if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("The hitchhiker's Guide to the Galaxy");//print out this movie
      System.out.println("Another Earth");//print out this movie
      System.out.println("Robot & Frank ");//print out this movie
    }else{//if the user is over then 18 do this
     System.out.println("I Think We're Alone Now");//print out this movie
     System.out.println("Sputnik");//print out this movie
     System.out.println("Intersect");//print out this movie
    }
    }else{//if the users answer does not equal movie then do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("The Gifted");//print out this show
      System.out.println("Firefly");//print out this show
      System.out.println("Dimension");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("The Gifted");//print out this show
     System.out.println("Motherland");//print out this show
     System.out.println("11.22.63");//print out this show
    }
   }
   }
  if(service == 3 && genera == 1){//if service is 3  genera is 1 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a show or a movie
    String viewing = scan.next();//saving the users answer
   if(viewing.equals("movie")){//if the answer equals movie then do this
    if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("47 Ronin");//print out this movie
      System.out.println("Across the Universe");//print out this movie
      System.out.println("The Adventures of Pinoochio");//print out this movie
    }else{//if the user is over 18 do this
     System.out.println("All Eyes on Me");//print out this movie
     System.out.println("12 Years of Slaves");//print out this movie
     System.out.println("47 Ronin");//print out this movie
    }
    }else{//if answer is not movie then do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Degrassi: The next Generation");//print out this show
      System.out.println("The cleaning lady");//print out this show
      System.out.println("The Closer");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("30 Coins");
     System.out.println("Angels in America");
     System.out.println("Band of Brothers");
    }
    }
  }
  if(service == 3 && genera == 2){//if service is 3  genera is 2 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or show
    String viewing = scan.next();//saving that answer
   if(viewing.equals("movie")){//if answer is movie then do this
       if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Accepted");//prints out this movie
      System.out.println("Elmo in grouch land");//prints out this movie
      System.out.println("9 to 5");//prints out this movie
    }else{//if the user is over 18 do this
     System.out.println("2 Guns");//prints out this movie
     System.out.println("9 to 5");//prints out this movie
     System.out.println("Accepted");//prints out this movie
    }
    }else{//if answer is not movie then do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Abbott Elementary");//print out this show
      System.out.println("Adam Ruins Everything");//print out this show
      System.out.println("Animals");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("2 Dope Queens");//prints out this show
     System.out.println("Avenue 5");//prints out this show
     System.out.println("The Baby");//prints out this show
    }
    }
  }
  if(service == 3 && genera == 3){//if service is 3  genera is 3 then do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
    String viewing = scan.next();//saves users answer
   if(viewing.equals("movie")){//if answer is movie then do this
    if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("16 Days of Glory");//prints out this movie
      System.out.println("38 at the Garden");//prints out this movie
      System.out.println("Andre the Giant");//prints out this movie
    }else{//if the user is over 18 do this
     System.out.println("61*");//prints out this movie
     System.out.println("Babe Ruth");//prints out this movie
     System.out.println("Against the Ropes");//prints out this movie
    }
    }else{//if answer is not movie then do this
    if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Arliss");//print out this show
      System.out.println("Ballers");//print out this show
      System.out.println("Being Serena");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("100 Foot Wave");//prints out this show
     System.out.println("What's my name Muhammad Ali");//prints out this show
     System.out.println("Ballers");//prints out this show
    }
    }
  }
  if(service == 3 && genera == 4){
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or show
    String viewing = scan.next();//saves users answer
   if(viewing.equals("movie")){//if answer is movie then do this
    if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("12 Rounds");//print out this show
      System.out.println("Abduction");//print out this show
      System.out.println("The adventures of Tintin");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("10,000 BC");//prints out this movie
     System.out.println("12 Rounds");//prints out this movie
     System.out.println("Abduction");//prints out this movie
    }
    }else{//if answer is not movie then do this
    if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Stargirl");//print out this show
      System.out.println("Primal");//print out this show
      System.out.println("Mortal Combat conquest");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("Banshee");//prints out this show
     System.out.println("Barry");//prints out this show
     System.out.println("Dios");//prints out this show
    }
    }
  }
  if(service == 3 && genera == 5){//if service is 3  genera is 5 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a show or a movie
    String viewing = scan.next();//saves the users answer
   if(viewing.equals("movie")){//if answer is movie then do this
       if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Are we not Done Yet");//prints out this movie
      System.out.println("Band Slam");//prints out this movie
      System.out.println("Alvin and the Chipmunks");//prints out this movie
    }else{//if the user is over 18 do this
     System.out.println("Sharkboy and Lavagirl");//prints out this movie
     System.out.println("Alvin and the Chipmuncks");//prints out this movie
     System.out.println("Amazing Grace");//prints out this movie
    }
    }else{//if answer is not movie then do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("The adventures of Aquaman");//prints out this movie
      System.out.println("The Batman");//prints out this movie
      System.out.println("Ben 10");//prints out this movie
    }else{//if the user is over 18 do this
     System.out.println("The Flintstones");//prints out this show
     System.out.println("Craig of the Creek");//prints out this show
     System.out.println("Courage the Cowaradly Dog");//prints out this show
    }
    }
  }
  if(service == 3 && genera == 6){//if service is 3  genera is 6 then do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they would like to watch a movie or a show
    String viewing = scan.next();//saving that answer
   if(viewing.equals("movie")){//if answer is movie then do this
     if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("All about Steve");//prints out this movie
      System.out.println("Algo Azul");//prints out this movie
      System.out.println("(500) Days of Summer");//prints out this movie
    }else{//if the user is over 18 do this
     System.out.println("50 First Dates");//prints out this movie
     System.out.println("13 Going on 30");//prints out this movie
     System.out.println("At First Sight");//prints out this movie
    }
    }else{//if answer is not movie then do this
     if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Adventures of the ring");//print out this show
      System.out.println("The Bachelorette");//print out this show
      System.out.println("Deep down");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("The Bachelor");//prints out this show
     System.out.println("Bad Teacher");//prints out this show
     System.out.println("The Bachelorette");//prints out this show
    }
    }
  }
  if(service == 3 && genera == 7){// if service is 3  genera is 7 then do this
   System.out.println("Would you like to watch a movie or a show");//asking if the user would like to watch a movie or show
    String viewing = scan.next();//saving the users answer
   if(viewing.equals("movie")){//if answer is movie do this
       if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("You are too young to watch horror, we recommend Scooby-Doo");//print out this movie
    }else{//if the user is over 18 do this
     System.out.println("American Psycho");//Prints out this movie
     System.out.println("Annabelle");//prints out this movie
     System.out.println("Bug");//prints out this movie
    }
    }else{//if answer is not movie then do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("You are too young to watch horror, we recommend Scooby-Doo");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("Grace");//prints out this show
     System.out.println("Halfworlds");//prints out this show
     System.out.println("The Outsider");//prints out this show
    }
    }
  }
  if(service == 3 && genera == 8){//if service is 3  genera is 8 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a show or a movie
    String viewing = scan.next();//saving the users answer
   if(viewing.equals("movie")){//if answer is movie do this
     if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Under the Stars");//print out this show
      System.out.println("12th and Delaware");//print out this show
      System.out.println("93Q(een)");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("Agents of Chaos: The Attack on the 2016 Election");//prints out this movie
     System.out.println("The Alzheimer's Project");//prints out this movie
     System.out.println("Allen V. Farrow");//prints out this movie
    }
    }else{//if answer is not movie then do this
     if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Branson");//prints out this show
      System.out.println("Africa");//prints out this show
      System.out.println("Blue Planet II");//prints out this show
    }else{//if the user is over 18 do this
     System.out.println("3 1/2 Minutes Ten Bullets");//prints out this show
     System.out.println("40 Years a Prisoner");//prints out this show
     System.out.println("50 Children the Rescue Mission of Mr. & Mrs. Kraus");//prints out this show
    }
    }
  }
  if(service == 3 && genera == 9){//if service is 3  genera is 9 then do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a show or a movie
    String viewing = scan.next();//saves the users answer
   if(viewing.equals("movie")){//if answer is movie then do this
     if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Aireplane II the Sequal");//prints out this show
      System.out.println("Babylon A.D.");//prints out this show
      System.out.println("Astro Boy");//prints out this show
    }else{//if the user is over 18 do this
     System.out.println("2001: A Space Odyssey");
     System.out.println("2010 The Year we Make Contact");//prints out this movie
     System.out.println("Aeon Flux");//prints out this movie
    }
    }else{//if answer is not movie then do this
     if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Babylon 5");//prints out this show
      System.out.println("Doctor Who");//prints out this show
      System.out.println("Fringe");//prints out this show
    }else{//if the user is over 18 do this
     System.out.println("Doctor Who");//prints out this show
     System.out.println("Fantasmagorias");//prints out this show
     System.out.println("El Hipnotizador");//prints out this show
    }
    }
  }
  if(service == 4 && genera == 1){//if service equals 4  genera equals 1 then do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
   String viewing = scan.next();//saving the users answer
   if(viewing.equals("movie")){//if the users answer is equal to movie then do this
       if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Black Beauty");//print out this movie
      System.out.println("Edward Scissorhands");//print out this movie
      System.out.println("Hidden Figures");//print out this movie
    }else{//if the user is over 18 do this
     System.out.println("Black Beauty");//print out this movie
     System.out.println("Edward Scissorhands");//print out this movie
     System.out.println("Hidden Figures");//print out this movie
    }
    }else{//if the users answer does not equal movie then do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Delicacies Destiny");//print out this show
      System.out.println("The Evermoor Chronicles");//print out this show
      System.out.println("Ms. Marvel");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("Daredevil");//print out this show
     System.out.println("Delicacies Destiny");//print out this show
     System.out.println("The Ever More Chronicles");//print out this show
    }
    }
  }
  if(service == 4 && genera == 2){//if service is equal to 4  genera is equal to 2 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
   String viewing = scan.next();//saving that answer
   if(viewing.equals("movie")){//if the users answer equals movie then do this
       if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Ant-Man");//print out this movie
      System.out.println("Big");//print out this movie
      System.out.println("Dr. Dolittle");//print out this movie
    }else{//if the user is over 18 do this
     System.out.println("Ant-Man");//print out this movie
     System.out.println("Big");//print out this movie
     System.out.println("Dr. Dolittle");//print out this movie
    }
    }else{//if the users answer does not equal movie do this
     if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Diary of a Future President");//print out this show
      System.out.println("Dog with a Blog");//print out this show
      System.out.println("Kim Posible");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("Diary of a Future President");//print out this show
     System.out.println("Dog With a Blog");//print out this show
     System.out.println("Grown-ish");//print out this show
    }
    }
  }
  if(service == 4 && genera == 3){//if service is 4  genera is 3 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
   String viewing = scan.next();//saving the users answer
   if(viewing.equals("movie")){//if the users answer is equal to movie then do this
       if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("The Day the Series Stopped");//print out this movie
      System.out.println("Dickie V");//print out this movie
      System.out.println("Four Falls of Buffalo");//print out this movie
    }else{//if the user is over 18 do this
     System.out.println("The Day the Series Stopped");//print out this movie
     System.out.println("Dickie V");//print out this movie
     System.out.println("Four Falls of Buffalo");//print out this movie
    }
    }else{//if the users answer does not equal movie then do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Save our Squad with David Beckham");//print out this show
      System.out.println("The Might Ducks Game Changers");//print out this show
      System.out.println("Big Shot");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("Save our Squad With David Beckham");//prints out this show
     System.out.println("The Mighty Ducks Game Changers");//prints out this show
     System.out.println("Big Shot");//prints out this show
    }
    }
  }
  if(service == 4 && genera == 4){//if service is 4  genera is 4 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
   String viewing = scan.next();//saves their answer
   if(viewing.equals("movie")){//if answer is movie do this
       if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Bridge to Terabithia");//print out this movie
      System.out.println("Narnia: The Lion, The Witch, and the Wardrobe");//print out this movie
      System.out.println("Adventures in Babysitting");//print out this movie
    }else{//if the user is over 18 do this
     System.out.println("Bridge to Terabithia");//prints out this movie
     System.out.println("Deadpool");//prints out this movie
     System.out.println("Narnia: the Lion, the Witch, and the Wardeobe");//prints out this movie
    }
    }else{//if answer is not movie do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("The Owl House");//print out this show
      System.out.println("Wolverine and the X-Men");//print out this show
      System.out.println("Zorro");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("Willow");//prints out this show
     System.out.println("Alias");//prints out this show
     System.out.println("Luke Cage");//prints out this show
    }
    }
  }
  if(service == 4 && genera == 5){//if service is 4  genera is 5 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a show or a movie
   String viewing = scan.next();//saves their answer
   if(viewing.equals("movie")){//if answer is movie do this
       if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("The Book of Life");//print out this show
      System.out.println("Brother Bear");//print out this show
      System.out.println("A Goofy Movie");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("The Book of Life");//prints out this movie
     System.out.println("Brother Bear");//prints out this movie
     System.out.println("A Goofy Movie");//prints out this movie
    }
    }else{//if answer is not do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Elena of Avalor");//print out this show
      System.out.println("Fishhooks");//print out this show
      System.out.println("Amphibia");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("Ms. Marvel");//prints out this show
     System.out.println("Elena of Avalor");//prints out this show 
     System.out.println("Fishhooks");//prints out this show
    }
    }
  }
  if(service == 4 && genera == 6){//if service is 4  genera is 6 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
   String viewing = scan.next();//saves thier answer
   if(viewing.equals("movie")){//if answer is movie than do this
       if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("10 Things I hate about You");//print out this movie
      System.out.println("West Side Story");//print out this movie
      System.out.println("The Princess Bride");//print out this move
    }else{//if the user is over 18 do this
     System.out.println("10 Things I Hate About You");//prints out this movie
     System.out.println("West Side Story");//prints out this movie
     System.out.println("The Princess Bride");//prints out this movie
    }
    }else{
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("High School Musical the Musical the Series");//print out this show
      System.out.println("Disney's Fairy Tale Weddings");//print out this show
      System.out.println("Violetta");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("High School Musical the Musical the Series");//prints out this show
     System.out.println("Disney's Fairy Tale Weddings");//prints out this show
     System.out.println("Violetta");//prints out this show
    }
    }
  }
  if(service == 4 && genera == 7){//if service is 4  genera is 7 then do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if the would like movie or show
   String viewing = scan.next();//saving users answer
   if(viewing.equals("movie")){//if answer is movie then do this
       if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("You are too young to watch a horror movie, we reccomend Scooby-Doo");//print out this movie
    }else{//if the user is over 18 do this
     System.out.println("Werewolf by Night");//prints out this movie
     System.out.println("Don't Look Under the Bed");//prints out this movie
     System.out.println("The Adventures of Ichabod and Mr. Toad");//prints out this movie
    }
    }else{//if answer is not movie then do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("You are too young to watch horror shows, we recommend Scooby-Doo");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("Just Beyond");//prints out this show
     System.out.println("Tierra Incognita");//prints out this show
     System.out.println("The Simpsoms: Treehouse of Horrors");//prints out this show
    }
    }
  }
  if(service == 4 && genera == 8){//if service is 4  genera is 8 do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a show or a movie
   String viewing = scan.next();//saves thier answer
   if(viewing.equals("movie")){//if answer is movie then do this
       if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Akashinga: The Brave Ones");//print out this movie
      System.out.println("Apollo: Missions to the Moon");//print out this movie
      System.out.println("Elephant");//print out this movie
    }else{//if the user is over 18 do this
     System.out.println("Akashinga: The Brave Ones");//prints out this movie
     System.out.println("Apollo: Missions to the Moon");//prints out this movie
     System.out.println("Elephant");//prints out this movie
    }
    }else{
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Cosmos: Possible Worlds");//print out this show
      System.out.println("Growing Up Animal");//print out this show
      System.out.println("Growing Up");//print out this show
    }else{
     System.out.println("Cosmos: Possible Worlds");//prints out this show
     System.out.println("Atlas of Curses Places");//prints out this show
     System.out.println("Growing Up Animal");//prints out this show
    }
    }
    } 
  if(service == 4 && genera == 9){//if service is 4  genera is 9 then do this
   System.out.println("Would you like to watch a movie or a show");//asking the user if they would like to watah a movie or a show
   String viewing = scan.next();//saves their answer
   if(viewing.equals("movie")){//if answer is movie then do this
       if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Big Hero 6");//print out this movie
      System.out.println("Free Guy");//print out this movie
      System.out.println("Star");//print out this movie
    }else{//if the user is over 18 do this
     System.out.println("Big Hero 6");//prints out this movie
     System.out.println("Free Guy");//prints out this movie
     System.out.println("Star Wars: A New Hope");//prints out this movie
    }
    }else{
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Spaced Out");//print out this show
      System.out.println("Lab Rats");//print out this show
      System.out.println("Parallels");//print out this show
    }else{//if the user is over 18 do this
     System.out.println("Spaced Out");//prints out this show
     System.out.println("Lab Rats");//prints out this show
     System.out.println("Parallels");//prints out this show
    }
   }
  }
  if(service == 5  && genera == 1){//if service is 5   genera is 1 then do this
    System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
    String viewing = scan.next();//saving the users answer
    if(viewing.equals("movie")){//if answer is movie then do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Free Willy");//print out this movie
      System.out.println("The Fix It Boys");//print out this movie
      System.out.println("The Sisterhood of the Traviling Pants");//print out this movie
    }else{//if the user is over 18 do this
      System.out.println("The Sisterhood of the Traviling Pants");//prints out this movie
      System.out.println("Set it Off");//prints out this movie
      System.out.println("Lolita");//prints out this movie
    }
     }else{//if answer is not movie then do this
    if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("6 Teen");//print out this show
      System.out.println("The Temptations");//print out this show
      System.out.println("Degrassi: The Next Generation");//print out this show
    }else{//if the user is over 18 do this
      System.out.println("Degrassi: The Next Generation");//prints this show
      System.out.println("The Fix");//prints this show
      System.out.println("Heartland");//prints this show
     }
    }
   }
   if(service == 5  && genera == 2){//if service is 5 genera is 2 then do this
    System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
    String viewing = scan.next();//saving the users answer
    if(viewing.equals("movie")){//if answer is movie then do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Big");//print out this movie
      System.out.println("The Pink Panther");//print out this movie
      System.out.println("Mr. Bean");//print out this movie
    }else{//if the user is over 18 do this
      System.out.println("Just Wright");//prints out this movie
      System.out.println("There's Something about Mary");//prints out this movie
      System.out.println("Moonstruck");//prints out this movie
    }
     }else{//if answer is not movie then do this
         if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Everybody hates Chris");//print out this show
      System.out.println("Sister, Sister");//print out this show
      System.out.println("The Nanny");//print out this show
    }else{//if the user is over 18 do this
      System.out.println("Loving till it Hurts");//prints out this show
      System.out.println("The Game");//prints out this show
      System.out.println("Nada Es Eterno (Doblado)");//prints out this show
    }
     }
   }
   if(service == 5 && genera == 3){//if service is 5 genera is 3 then do this
    System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
    String viewing = scan.next();//saving the users answer
    if(viewing.equals("movie")){//if answer is movie then do this
    if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Offside");//prints out this movie
      System.out.println("Million Dollar Baby");//prints out this movie
      System.out.println("Boxed in");//prints out this movie
    }else{//if the user is over 18 do this
      System.out.println("The 5th Wave");//prints out this movie
      System.out.println("Godzilla");//prints out this movie
      System.out.println("Dunkirk");//prints out this movie
     }
     }else{//if answer is not movie do this
         if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Bring it");//print out this show
      System.out.println("Dark Side of the Ring");//print out this show
      System.out.println("The Westminster Kennel Club Dog Show");//print out this show
    }else{//if the user is over 18 do this
      System.out.println("Naruto");//prints out this show
      System.out.println("Revolution");//prints out this show
      System.out.println("The A-Team");//prints out this show
     }
     }
   }
   if(service == 5  && genera == 4){//if service is 5  genera is 4 then do this
    System.out.println("Would you like to watch a movie or a show");//asking if the user wants to watch a movie or a show
    String viewing = scan.next();//saving the users answer
    if(viewing.equals("movie")){//if the answer is movie do this
     if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("The 5th Wave");//print out this show
      System.out.println("The Chronicles of Riddick");//print out this show
      System.out.println("Godzilla");//print out this show
    }else{//if the user is over 18 do this
      System.out.println("Doctor Sleep");//prints out this moive
      System.out.println("Freddy vs. Jason");//prints out this movie
      System.out.println("Terrifier");//prints out this movie
    }
     }else{//if answer is not movie then do this
         if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("One Punch Man");//print out this show
      System.out.println("LEGO Ninjago Masters of Spinjitzu");//print out this show
      System.out.println("The A-Team");//print out this show
    }else{//if the user is over 18 do this
      System.out.println("Celebrity Ghost Stories");//prints out this show
      System.out.println("Spook Show 17");//prints out this show
      System.out.println("Dracula");//prints out this show
     }
    }
   }
   if(service == 5  && genera == 5){//if service is 5  genera is 5 then do this
    System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
    String viewing = scan.next();//saving the users answer
    if(viewing.equals("movie")){//if the answer is movie then do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("The Spy Next Door");//print out this movie
      System.out.println("Missing Link");//print out this movie
      System.out.println("Dear Dumb Diary");//print out this movie
    }else{//if the user is over 18 do this
      System.out.println("Scariest Monsters in America");//prints out this movie
      System.out.println("Killing Diana");//prints out this movie
      System.out.println("Bob Lazar: Area 51 & Flying Saucers");//prints out this movie
    }
     }else{//if the answer is not movie then do this
      if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Scooby-Doo Where are You?");//print out this show
      System.out.println("Littlest Pet Shop");//print out this show
      System.out.println("Camp Lakebottom");//print out this show
    }else{//if the user is over 18 do this
      System.out.println("Forensic Files");//prints out this show
      System.out.println("Wildlife Icons");//prints out this show
      System.out.println("The World's Strangest Mysteries");//prints out this show
    }
     }
   }
   if(service == 5  && genera == 6){//if service is 5  genera  is 6 do this
    System.out.println("Would you like to watch a movie or a show");//asking the user if they would like to watch a movie or a show
    String viewing = scan.next();//saves the user answer
    if(viewing.equals("movie")){//if the answer is movie do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Just Wright");//print out this movie
      System.out.println("Moonstruck");//print out this movie
      System.out.println("Rocks of Ages");//print out this movie
    }else{//if the user is over 18 do this
      System.out.println("The Spy Next Door");//prints this movie
      System.out.println("Missing Link");//prints this movie
      System.out.println("Dear Dumb Diary");//prints this movie
    }
     }else{//if the answer is not movie then do this
     if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Loving till It Hurts");//print out this show
      System.out.println("The Game");//print out this show
      System.out.println("Nada Es Eterno (Doblado)");//print out this show
     }else{//if the user is over 18 do this
      System.out.println("Scooby-Doo Where are You?");//prints out this show
      System.out.println("Littlest Pet Shop");//prints out this show
      System.out.println("Camp Lake Bottom");//prints out this show
     }
     }
   }
   if(service == 5  && genera == 7){//if service is 5  genera is 7 then do this
    System.out.println("Would you like to watch a movie or a show");//asking if the user wants to watch a movie or a show
    String viewing = scan.next();//saving the users answer
    if(viewing.equals("movie")){//is the answer is movie then do this
    if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("You are too young to watch horror, we recommend the Scooby-Doo Movie");//print out this movie
    }else{//if the user is over 18 do this
      System.out.println("Cowboys & Aliens");//prints out this movie
      System.out.println("Blade Runner 2049");//prints out this movie
      System.out.println("Risen");//prints out this movie
    }
     }else{//if the answer is not movie then do this
         if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("You are too young to watch horror, We recommend any Scooby-Doo Show");//print out this show
    }else{//if the user is over 18 do this
      System.out.println("Farscape");//prints out this show
      System.out.println("Sanctuary");//prints out this show
      System.out.println("The Triangle");//prints out this show
    }
     }
    }
   if(service == 5  && genera == 8){//if service is 5  genera is 8 then do this
    System.out.println("Would you like to watch a movie or a show");//asking the user if they want to watch a movie or a show
    String viewing = scan.next();//saving the users answer
    if(viewing.equals("movie")){//if the answer is equal to movie
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Mysteries From the Grave: Titanic");//prints out this movie
      System.out.println("Close Encounters of the Fifth kind");//prints out this movie
      System.out.println("A Race of Giants");//prints out this show
     }else{//if the user is over 18 do this
      System.out.println("Big");//prints out this movie
      System.out.println("The Pink Panther");//prints out this movie
      System.out.println("Mr. Bean");//prints out this movie
     }
     }else{//if the answer is not movie do this
     if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Reclaiming the Throne");//print out this show
      System.out.println("Unsealed Alien Files");//print out this show
      System.out.println("Wildlife Icons");//print out this show
     }else{//if the user is over 18 do this
      System.out.println("Everybody Hates Chris");//prints out this show
      System.out.println("The Adams Family");//prints out this show
      System.out.println("Sister, Sister");//prints out this show
     }
     }
   }
   if(service == 5  && genera == 9){//if service is 5  genera is 9 then do this 
    System.out.println("Would you like to watch a movie or a show");//asking the user if they would like to watch a move or a show
    String viewing = scan.next();//saving the users answer
    if(viewing.equals("movie")){//if the answer equals movie do this
        if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Cowboys & Aleins");//prints out this movie
      System.out.println("Journey to the Center of the Earth");//prints out this movie
      System.out.println("Apocalypse of Ice");//prints out this movie
    }else{//if the user is over 18 do this
      System.out.println("Offside");//prints out this movie
      System.out.println("Million Dollor Baby");//prints out this movie
      System.out.println("Boxed In");//prints out this movie
    }
     }else{//if the answer is not movie do this
         if(user1id.getage() < 18 || user2id.getage() < 18 || user3id.getage() < 18){//if the users age is less than 18 do this
      System.out.println("Battlestar Galactica (Classic)");//prints out this show
      System.out.println("The Triangle");//prints out this show
      System.out.println("Farscape");//prints out this show
    }else{//if the user is over 18 do this
      System.out.println("Bring It");//prints out this show
      System.out.println("Dark Side of The Ring");//prints out this show
      System.out.println("The Westminster Kennel Club Dog Show");//prints out this show
     }
    }
   }
   if(genera == 10){//if genera equals 10 then do this
    System.out.println("Please enter the password");//asking the user to enter the passowrd
    String pass = scan.next();//saving their answer
    if(pass.equals("Adam_Sandler") || pass.equals("Mosquito-man")){//if the user inputs either of these "Passwords" then do this
     System.out.println("You found the secrect, congrats!");//congratulating the user finding the secret genera
     System.out.println("Would you like to watch a Gay movie or a Gay show (Please input movie or show)");//asking the user if they want to watch a gay movie or a gay show
     String viewing = scan.next();//taking in that answer
      if(viewing.equals("movie")){//if the answer is equal to movie then do this
       System.out.println("But I'm A Chearleader");//prints out this movie
       System.out.println("Blue Is The Warmest Color");//prints out this movie
       System.out.println("Portrait Of A Lady On Fire");//prints out this movie
       }else{//if the answer is not movie do this 
       System.out.println("Killing Eve");//prints out this show
       System.out.println("The L Word");//prints out this show
       System.out.println("Pose");//prints out this show
      }
     }
    }
   }
 public String Service(){//another method for the different services used
   Random rand = new Random();//calling the random generator into the method
  int service = rand.nextInt(5);//creating a random number generator with a max of 5
  switch(service){//whatever number service is it goes to said case
   case 1://if service is 1 do this
   return "We have selected Netflix";//return Netflix
   case 2://if service is 2 do this
   return "We have selected Hulu";//return Hulu
   case 3://if service is 3 do this
   return "We have selected HBO Max";//return HBO Max
   case 4://if service is 4 do this
   return "We have selected Disney+";//return Disney+
   default://if the number is 5 do this
   return "We have selected Tubi";//return Tubi
  }
 }
}