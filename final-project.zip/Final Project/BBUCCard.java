
/**
 * Write a description of class BBUCCard here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class BBUCCard{//start of the class
 private String name;//name stays only in this class
 private int age;//age only stays in this class
 private int id;//id only stays in this class
 public void User(String n, int a, int i){//taking in the name, age, and id for the user
  name = n;//setting name equal to n
  age = a;//setting age equal to a
  id = i;//setting id equal to i
 }
 public String getName(){//getting the name from the user
  return name;//returning thie users name
 }
 public int getage(){//getting the users age
  return age;//returning the users age
 }
 public int getID(){//getting the users ID
  return id;//returning the users ID
 }
 public void setName(String n){//taking in the users name
  name = n;//setting name to equal the users name
 }
 public void setage(int a){//taking in the users age
  age = a;//setting age to equal the users age
 }
 public void setID(int i){//taking in the users ID
  id = i;//setting id to equal the users id
 }
 public String toString(){//putting the users name, age, and ID together
  return "User; name: " +name+ " age: " +age+ " ID: " +id;//returning the users name, age, and ID number
 }
}
